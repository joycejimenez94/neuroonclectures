# Neuro-Oncology Fellowship Curriculum

Standalone, static GitHub Pages website with six concise educational neuro-oncology lessons.

## Publish with GitHub Pages

1. Sign in to GitHub and create a **public** repository named `neuro-oncology-curriculum`.
2. Choose **Add file → Upload files** and upload `index.html`, `style.css`, `script.js`, `lessons.json`, and `README.md` to the **root** of the repository (not inside a subfolder). Commit changes.
3. Open **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**. Set branch **main**, folder **/(root)**, then Save.
4. After deployment, the URL is usually `https://YOUR-USERNAME.github.io/neuro-oncology-curriculum/`.

## Add a lesson

Edit `lessons.json` on GitHub. Add an object to the array with `id`, `title`, `subtitle`, `date`, `sections` (array of `{heading,text}`), and `references` (array of `{label,url}`). Increment the ID. Commit; Pages redeploys. The site automatically updates the sidebar and lesson count.

## Important

Lessons summarize educational content prepared September–October 2026. They are not automatically updated or independently revalidated against current NCCN content. Verify guidance, local protocols, and prescribing information before clinical decisions. Do not enter patient identifiers into the site.
